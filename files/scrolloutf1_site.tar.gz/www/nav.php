<ul id="menu">
                <li>
                                <a href="connection.html"><span class="mi">&#xE839;</span>&nbsp;&nbsp;&nbsp;CONNECT</a>


                </li>
                <li>
                                <a href="traffic.html"><span class="mi">&#xE13C</span>&nbsp;&nbsp;&nbsp;ROUTE</a>
                </li>
                <li>
                                <a href="security.html"><span class="mi">&#xE83D</span>&nbsp;&nbsp;&nbsp;SECURE</a>
                                <ul>
                                                <li>
                                                                <a href="security.html"><i class="fa fa-sliders fa-2x"></i>&nbsp;&nbsp;&nbsp;LEVELS</a>
                                                </li>
                                                <li>
                                                                <a href="lists.html"><span class="mi">&#xE25B</span>&nbsp;&nbsp;&nbsp;SENDERS</a>
                                                </li>
                                                <li>
                                                                <a href="countries.html"><span class="mi">&#xE909</span>&nbsp;&nbsp;&nbsp;COUNTRIES</a>
                                                </li>
                                                <li>
                                                                <a href="cert.html"><span class="mi">&#xEC1B</span>&nbsp;&nbsp;&nbsp;CERTIFICATE</a>
                                                </li>
                                                <li>
                                                                <a href="pwd.html"><span class="mi">&#xE192</span>&nbsp;&nbsp;&nbsp;PASSWORD</a>
                                                </li>
                                </ul>
                </li>
                <li>
                                <a href="collector.html"><span class="mi">&#xEDAB</span>&nbsp;&nbsp;&nbsp;COLLECT</a>
                </li>
                <li>
                                <a href="logs.php"><span class="mi">&#xE890</span>&nbsp;&nbsp;&nbsp;MONITOR</a>
                                <ul>
                                        <li>
                                        <a href="logs.php"><span class="mi">&#xE82D</span>&nbsp;&nbsp;&nbsp;LOGS</a>
                                        </li>
                                        <li>
                                        <a href="graph.php"><span class="mi">&#xE9D9</span>&nbsp;&nbsp;&nbsp;STATS</a>
                                        </li>
                                </ul>
                </li>


</ul>

