<?php

echo system('/var/www/cgi-bin/mailgraph.cgi');

?>